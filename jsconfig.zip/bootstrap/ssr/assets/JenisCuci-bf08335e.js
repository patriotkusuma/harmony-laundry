import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { A as AdminLayout } from "./AdminLayout-9fb4ec8e.js";
import { Card, CardHeader, Row, Col, Form, InputGroup, Input, Button, Table, CardFooter, Container, Alert } from "reactstrap";
import PropTypes from "prop-types";
import { P as Pagination, M as ModalJenis, a as ModalDelete } from "./ModalDelete-fc18f7aa.js";
import { useForm } from "@inertiajs/react";
const MyTable = (props) => {
  const { tableHead, data } = props;
  const [isOpen, setIsOpen] = useState(false);
  const [filtered, setFiltered] = useState();
  const [searchData, setSearchData] = useState();
  const [rowPerPage, setRowPerPage] = useState();
  const [currentPage, setCurrentPage] = useState(1);
  const [deleteOpen, setDeleteOpen] = useState(false);
  useForm();
  const toggleModal = () => {
    setIsOpen(isOpen != isOpen);
  };
  const addData = () => {
    setFiltered(null);
    setIsOpen(true);
  };
  const editData = (value) => {
    setFiltered(value);
    setIsOpen(true);
  };
  const deleteData = (value) => {
    setFiltered(value);
    setDeleteOpen(true);
  };
  const deleteToggle = () => {
    setDeleteOpen(deleteOpen != deleteOpen);
  };
  const pageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };
  const previousPage = () => {
    if (currentPage != 1) {
      setCurrentPage(currentPage - 1);
    }
  };
  const nextPage = () => {
    if (currentPage !== Math.ceil(data.total / rowPerPage)) {
      setCurrentPage(currentPage + 1);
    }
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsxs(CardHeader, { className: "d-flex flex-column justify-content-between", children: [
        /* @__PURE__ */ jsx("h3", { className: "mb-0", children: tableHead }),
        /* @__PURE__ */ jsx("div", { className: "mt-3 justify-content-between align-items-center", children: /* @__PURE__ */ jsxs(Row, { children: [
          /* @__PURE__ */ jsx(Col, { className: "order-xs-2", xs: "12", lg: "6", children: /* @__PURE__ */ jsxs(
            "select",
            {
              value: rowPerPage,
              onChange: (e) => setRowPerPage(e.target.value),
              className: "form-control-alternative form-control form-select-sm mr-3 w-25",
              children: [
                /* @__PURE__ */ jsx("option", { value: "5", children: "5" }),
                /* @__PURE__ */ jsx("option", { value: "10", children: "10" }),
                /* @__PURE__ */ jsx("option", { value: "25", children: "25" })
              ]
            }
          ) }),
          /* @__PURE__ */ jsx(Col, { className: "order-xs-1", xs: "12", lg: "3", children: /* @__PURE__ */ jsx(Form, { className: "justify-content-between ", children: /* @__PURE__ */ jsxs(InputGroup, { className: "input-group-alternative", children: [
            /* @__PURE__ */ jsx(
              Input,
              {
                id: "search",
                name: "search",
                type: "text",
                value: searchData ? searchData : "",
                onChange: (e) => setSearchData(e.target.value),
                placeholder: "Cari disini"
              }
            ),
            /* @__PURE__ */ jsx(
              Button,
              {
                className: "shadow-none border-none text-muted bg-transparent",
                onClick: (e) => e.preventDefault(),
                children: /* @__PURE__ */ jsx("i", { className: "fa-solid fa-magnifying-glass" })
              }
            )
          ] }) }) }),
          /* @__PURE__ */ jsx(Col, { className: "order-xs-3 justify-content-end d-flex", xs: "12", lg: "3", children: /* @__PURE__ */ jsxs(
            Button,
            {
              color: "primary",
              size: "md",
              onClick: addData,
              children: [
                /* @__PURE__ */ jsx("i", { className: "fa-solid fa-file-circle-plus mr-2" }),
                "Tambah Data"
              ]
            }
          ) })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxs(Table, { className: "align-items-center  table-flush", responsive: true, children: [
        /* @__PURE__ */ jsx("thead", { className: "thead-light", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { scope: "col", children: "No" }),
          /* @__PURE__ */ jsx("th", { scope: "col", children: "Jenis Cuci" }),
          /* @__PURE__ */ jsx("th", { scope: "col", children: "Harga" }),
          /* @__PURE__ */ jsx("th", { scope: "col", children: "Tipe" }),
          /* @__PURE__ */ jsx("th", { scope: "col", children: "Keterangan" }),
          /* @__PURE__ */ jsx("th", { scope: "col", children: "Action" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { children: data.data.length == 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { className: "justify-content-center d-flex", colspan: 6, children: " Data tidak ada." }) }) : data.data.map((value, index) => {
          return /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("th", { scope: "row", children: (data.current_page - 2) * data.per_page + index + data.per_page + 1 }),
            /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx("span", { className: "mb-0 text-sm", children: value.nama }) }),
            /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx("span", { className: "mb-0 text-sm", children: value.harga }) }),
            /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx("span", { className: "mb-0 text-sm", children: value.tipe }) }),
            /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx("span", { className: "mb-0 text-sm", children: value.keterangan }) }),
            /* @__PURE__ */ jsxs("td", { children: [
              /* @__PURE__ */ jsxs(
                Button,
                {
                  color: "warning",
                  size: "sm",
                  onClick: () => editData(value),
                  children: [
                    /* @__PURE__ */ jsx("i", { class: "fa-solid fa-pen-to-square mr-2" }),
                    "Edit"
                  ]
                }
              ),
              /* @__PURE__ */ jsxs(
                Button,
                {
                  color: "danger",
                  size: "sm",
                  onClick: () => deleteData(value),
                  children: [
                    /* @__PURE__ */ jsx("i", { class: "fa-solid fa-trash-can mr-2" }),
                    "Hapus"
                  ]
                }
              )
            ] })
          ] }, index);
        }) })
      ] }),
      /* @__PURE__ */ jsx(CardFooter, { className: "py-4", children: /* @__PURE__ */ jsx("nav", { "aria-label": "....", children: /* @__PURE__ */ jsx(
        Pagination,
        {
          currentPage,
          rowPerPage: data.per_page,
          totalPosts: data.total,
          onPageChange: pageChange,
          previousPage,
          nextPage,
          lastPage: data.last_page
        }
      ) }) })
    ] }),
    /* @__PURE__ */ jsx(
      ModalJenis,
      {
        isOpen,
        toggleModal,
        filteredData: filtered
      }
    ),
    /* @__PURE__ */ jsx(
      ModalDelete,
      {
        isOpen: deleteOpen,
        toggleModal: deleteToggle,
        deleteData: filtered
      }
    )
  ] });
};
MyTable.propTypes = {
  tableHead: PropTypes.string.isRequired,
  data: PropTypes.array
};
const JenisCuci = (props) => {
  const { auth, pakets, flash } = props;
  useState();
  return /* @__PURE__ */ jsx(
    AdminLayout,
    {
      header: "Paket Laundry",
      user: auth.user,
      children: /* @__PURE__ */ jsx("header", { className: "bg-gradient-info pb-8 pt-5 pt-md-8", children: /* @__PURE__ */ jsxs(Container, { fluid: true, children: [
        /* @__PURE__ */ jsxs(Alert, { color: "success", isOpen: flash.success != null ? true : false, children: [
          /* @__PURE__ */ jsx("strong", { children: "Success!" }),
          " ",
          flash.success != null && flash.success
        ] }),
        /* @__PURE__ */ jsx(Row, { children: /* @__PURE__ */ jsx("div", { className: "col", children: /* @__PURE__ */ jsx(
          MyTable,
          {
            data: pakets,
            tableHead: "Paket Laundry"
          }
        ) }) })
      ] }) })
    }
  );
};
JenisCuci.propTypes = {};
export {
  JenisCuci as default
};
