import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { Modal, Row, Col, Button, Form, FormGroup, Label, Input, FormFeedback, InputGroup, InputGroupText, Card, CardHeader, Table, CardFooter, Container } from "reactstrap";
import { useForm } from "@inertiajs/react";
import { P as Pagination } from "./ModalDelete-fc18f7aa.js";
import { A as AdminLayout } from "./AdminLayout-9fb4ec8e.js";
import moment from "moment";
const Delete = (props) => {
  const { isOpen, toggleModal, deleteData } = props;
  const { delete: destroy } = useForm();
  const submit = (e) => {
    e.preventDefault();
    destroy(
      route("dana-keluar.destroy", deleteData.id),
      {
        preserveScroll: true,
        preserveState: true,
        replace: true,
        onSuccess: () => toggleModal()
      }
    );
  };
  return /* @__PURE__ */ jsxs(
    Modal,
    {
      className: "modal-dialog-centered",
      toggle: toggleModal,
      isOpen,
      children: [
        /* @__PURE__ */ jsxs("div", { className: "modal-header", children: [
          /* @__PURE__ */ jsx("h2", { className: "modal-title", id: "modal-title-default", children: "Hapus Data" }),
          /* @__PURE__ */ jsx(
            "button",
            {
              "aria-label": "close",
              className: "close",
              "data-dismiss": "modal",
              type: "button",
              onClick: toggleModal,
              children: /* @__PURE__ */ jsx("span", { "aria-hidden": true, children: /* @__PURE__ */ jsx("i", { className: "fa-solid fa-xmark" }) })
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "modal-body", children: /* @__PURE__ */ jsxs(Row, { className: "align-items-center", children: [
          /* @__PURE__ */ jsx(Col, { md: "2", children: /* @__PURE__ */ jsx("h1", { className: "text-danger", children: /* @__PURE__ */ jsx("i", { class: "fa-solid fa-triangle-exclamation fa-2xl" }) }) }),
          /* @__PURE__ */ jsx(Col, { md: "10 justify-content-start", children: /* @__PURE__ */ jsxs("h3", { className: "", children: [
            "Apakah anda yakin menghapus data",
            /* @__PURE__ */ jsx(
              Button,
              {
                color: "danger",
                size: "sm",
                children: deleteData != null ? deleteData.keperluan : ""
              }
            ),
            /* @__PURE__ */ jsx("span", { className: "", children: "?" })
          ] }) })
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "modal-footer", children: [
          /* @__PURE__ */ jsxs(
            Button,
            {
              color: "danger",
              type: "submit",
              size: "md",
              onClick: submit,
              children: [
                /* @__PURE__ */ jsx("i", { className: "fa-regular fa-trash-can" }),
                /* @__PURE__ */ jsx("span", { children: "Ya, Hapus Data" })
              ]
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              className: "ml-auto",
              color: "link",
              "data-dismiss": "modal",
              type: "button",
              onClick: toggleModal,
              children: "Close"
            }
          )
        ] })
      ]
    }
  );
};
Delete.propTypes = {
  isOpen: PropTypes.bool,
  toggleModal: PropTypes.func,
  deleteData: PropTypes.array
};
const Tambah = (props) => {
  const { isOpen, filteredData, toggleModal } = props;
  const { data, setData, errors, reset, patch, post, get, processing, recentySuccessfull } = useForm({
    id: "",
    keperluan: "",
    jumlah_keluar: "",
    bukti_keluar: "",
    keterangan: "",
    tanggal_keluar: ""
  });
  const addCommas = (num) => num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  const removeNonNumeric = (num) => num.toString().replace(/[^0-9]/g, "");
  const numberWithComma = (e) => {
    setData("jumlah_keluar", addCommas(removeNonNumeric(e.target.value)));
  };
  useEffect(() => {
    if (filteredData != null) {
      setData({
        id: filteredData.id,
        keperluan: filteredData.keperluan,
        jumlah_keluar: addCommas(removeNonNumeric(filteredData.jumlah_keluar)),
        bukti_keluar: filteredData.bukti_keluar,
        keterangan: filteredData.keterangan,
        tanggal_keluar: filteredData.tanggal_keluar
      });
    } else {
      setData({
        id: "",
        keperluan: "",
        jumlah_keluar: "",
        bukti_keluar: "",
        keterangan: "",
        tanggal_keluar: ""
      });
    }
  }, [filteredData]);
  const submit = (e) => {
    if (filteredData == null) {
      post(route(route().current()), {
        onSuccess: () => toggleModal()
      });
    } else {
      patch(route("dana-keluar.update", filteredData, filteredData.id), {
        preserveState: true,
        replace: true,
        preserveScroll: true,
        onSuccess: () => toggleModal()
      });
    }
  };
  return /* @__PURE__ */ jsxs(
    Modal,
    {
      className: "modal-dialog-centered",
      toggle: toggleModal,
      isOpen,
      children: [
        /* @__PURE__ */ jsxs("div", { className: "modal-header", children: [
          /* @__PURE__ */ jsxs("h2", { className: "modal-title", id: "modal-title-default", children: [
            filteredData == null ? "Tambah" : "Edit",
            " Data Dana Keluar"
          ] }),
          /* @__PURE__ */ jsx(
            "button",
            {
              "aria-label": "close",
              className: "close",
              "data-dismiss": "modal",
              type: "button",
              onClick: toggleModal,
              children: /* @__PURE__ */ jsx("span", { "aria-hidden": true, children: /* @__PURE__ */ jsx("i", { className: "fa-solid fa-xmark" }) })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "modal-body", children: [
          /* @__PURE__ */ jsxs(Form, { role: "form", onSubmit: submit, children: [
            /* @__PURE__ */ jsxs(FormGroup, { children: [
              /* @__PURE__ */ jsx(
                Label,
                {
                  className: "form-control-label",
                  children: "Keperluan"
                }
              ),
              /* @__PURE__ */ jsx(
                Input,
                {
                  className: "form-control-alternative",
                  id: "keperluan",
                  name: "keperluan",
                  placeholder: "Keperluan",
                  type: "text",
                  autoFocus: true,
                  defaultValue: filteredData != null ? filteredData.keperluan : "",
                  onChange: (e) => setData("keperluan", e.target.value),
                  invalid: errors.keperluan && true
                }
              ),
              /* @__PURE__ */ jsx(FormFeedback, { children: errors.keperluan && errors.keperluan })
            ] }),
            /* @__PURE__ */ jsxs(Row, { children: [
              /* @__PURE__ */ jsx(Col, { children: /* @__PURE__ */ jsxs(FormGroup, { children: [
                /* @__PURE__ */ jsx(
                  Label,
                  {
                    className: "form-control-label",
                    children: "Jumlah Keluar"
                  }
                ),
                /* @__PURE__ */ jsxs(InputGroup, { className: "input-group-alternative", children: [
                  /* @__PURE__ */ jsx(InputGroupText, { children: "Rp" }),
                  /* @__PURE__ */ jsx(
                    Input,
                    {
                      className: "form-control-alternative",
                      id: "jumlah_keluar",
                      name: "jumlah_keluar",
                      placeholder: "Jumlah Keluar",
                      type: "text",
                      value: data.jumlah_keluar,
                      defaultValue: filteredData != null ? filteredData.jumlah_keluar : "",
                      onChange: numberWithComma,
                      invalid: errors.jumlah_keluar && true
                    }
                  )
                ] }),
                errors.harga && /* @__PURE__ */ jsx("small", { style: { color: "#fb6340" }, className: "text-sm justify-content-start", children: errors.harga })
              ] }) }),
              /* @__PURE__ */ jsx(Col, { children: /* @__PURE__ */ jsxs(FormGroup, { children: [
                /* @__PURE__ */ jsx(
                  "label",
                  {
                    className: "form-control-label",
                    htmlFor: "exampleFormControlSelect1",
                    children: "Tipe"
                  }
                ),
                /* @__PURE__ */ jsx("br", {}),
                /* @__PURE__ */ jsx(
                  Input,
                  {
                    className: "form-control-alternative",
                    id: "tanggal_keluar",
                    name: "tanggal_keluar",
                    placeholder: "Tanggal Keluar",
                    type: "date",
                    defaultValue: filteredData != null ? filteredData.tanggal_keluar : "",
                    onChange: (e) => setData("tanggal_keluar", e.target.value),
                    invalid: errors.tanggal_keluar && true
                  }
                ),
                /* @__PURE__ */ jsx(FormFeedback, { children: errors.tipe && errors.tipe })
              ] }) })
            ] }),
            /* @__PURE__ */ jsxs(FormGroup, { children: [
              /* @__PURE__ */ jsx(
                Label,
                {
                  className: "form-control-label",
                  htmlFor: "bukti_keluar",
                  children: "Bukti Keluar"
                }
              ),
              /* @__PURE__ */ jsx(
                Input,
                {
                  className: "form-control-alternative",
                  id: "bukti_keluar",
                  name: "bukti_keluar",
                  placeholder: "Bukti Keluar",
                  type: "file",
                  accept: "image/*, .pdf",
                  defaultValue: filteredData != null ? filteredData.bukti_keluar : "",
                  onChange: (e) => setData("bukti_keluar", e.target.value),
                  invalid: errors.bukti_keluar && true
                }
              ),
              /* @__PURE__ */ jsx(FormFeedback, { children: errors.keperluan && errors.keperluan })
            ] }),
            /* @__PURE__ */ jsxs(FormGroup, { children: [
              /* @__PURE__ */ jsx(
                Label,
                {
                  className: "form-control-label",
                  children: "Keterangan"
                }
              ),
              /* @__PURE__ */ jsx(
                Input,
                {
                  className: "form-control-alternative",
                  id: "keterangan",
                  name: "keterangan",
                  placeholder: "Keterangan",
                  type: "textarea",
                  rows: "3",
                  autoFocus: true,
                  defaultValue: filteredData != null ? filteredData.keterangan : "",
                  onChange: (e) => setData("keterangan", e.target.value),
                  invalid: errors.keterangan && true
                }
              ),
              /* @__PURE__ */ jsx(FormFeedback, { children: errors.keterangan && errors.keterangan })
            ] }),
            /* @__PURE__ */ jsx("br", {})
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "d-flex justify-content-between", children: [
            /* @__PURE__ */ jsxs(Button, { color: "primary", type: "submit", disabled: processing, onClick: submit, children: [
              /* @__PURE__ */ jsx("i", { className: "fa-regular fa-floppy-disk" }),
              /* @__PURE__ */ jsx("span", { children: "Save changes" })
            ] }),
            /* @__PURE__ */ jsx(
              Button,
              {
                className: "ml-auto",
                color: "link",
                "data-dismiss": "modal",
                type: "button",
                onClick: toggleModal,
                children: "Close"
              }
            )
          ] })
        ] })
      ]
    }
  );
};
Tambah.propTypes = {
  isOpen: PropTypes.bool,
  toggleModal: PropTypes.func,
  filteredData: PropTypes.any
};
const CustomTable = (props) => {
  const { tableHead, data, headData, children, toggleModal, addData } = props;
  useState(false);
  useState();
  const [searchData, setSearchData] = useState();
  const [rowPerPage, setRowPerPage] = useState();
  const [currentPage, setCurrentPage] = useState(1);
  useState(false);
  useForm();
  const pageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };
  const previousPage = () => {
    if (currentPage != 1) {
      setCurrentPage(currentPage - 1);
    }
  };
  const nextPage = () => {
    if (currentPage !== Math.ceil(data.total / rowPerPage)) {
      setCurrentPage(currentPage + 1);
    }
  };
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs(Card, { children: [
    /* @__PURE__ */ jsxs(CardHeader, { className: "d-flex flex-column justify-content-between", children: [
      /* @__PURE__ */ jsx("h3", { className: "mb-0", children: tableHead }),
      /* @__PURE__ */ jsx("div", { className: "mt-3 justify-content-between align-items-center", children: /* @__PURE__ */ jsxs(Row, { children: [
        /* @__PURE__ */ jsx(Col, { className: "order-xs-2", xs: "12", lg: "6", children: /* @__PURE__ */ jsxs(
          "select",
          {
            value: rowPerPage,
            onChange: (e) => setRowPerPage(e.target.value),
            className: "form-control-alternative form-control form-select-sm mr-3 w-25",
            children: [
              /* @__PURE__ */ jsx("option", { value: "5", children: "5" }),
              /* @__PURE__ */ jsx("option", { value: "10", children: "10" }),
              /* @__PURE__ */ jsx("option", { value: "25", children: "25" })
            ]
          }
        ) }),
        /* @__PURE__ */ jsx(Col, { className: "order-xs-1", xs: "12", lg: "3", children: /* @__PURE__ */ jsx(Form, { className: "justify-content-between ", children: /* @__PURE__ */ jsxs(InputGroup, { className: "input-group-alternative", children: [
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "search",
              name: "search",
              type: "text",
              value: searchData ? searchData : "",
              onChange: (e) => setSearchData(e.target.value),
              placeholder: "Cari disini"
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              className: "shadow-none border-none text-muted bg-transparent",
              onClick: (e) => e.preventDefault(),
              children: /* @__PURE__ */ jsx("i", { className: "fa-solid fa-magnifying-glass" })
            }
          )
        ] }) }) }),
        /* @__PURE__ */ jsx(Col, { className: "order-xs-3 justify-content-end d-flex", xs: "12", lg: "3", children: /* @__PURE__ */ jsxs(
          Button,
          {
            color: "primary",
            size: "md",
            onClick: addData,
            children: [
              /* @__PURE__ */ jsx("i", { className: "fa-solid fa-file-circle-plus mr-2" }),
              "Tambah Data"
            ]
          }
        ) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxs(Table, { className: "align-items-center  table-flush", responsive: true, children: [
      /* @__PURE__ */ jsx("thead", { className: "thead-light", children: /* @__PURE__ */ jsx("tr", { children: headData.map((th, index) => {
        return /* @__PURE__ */ jsx("th", { scope: "col", children: th }, index);
      }) }) }),
      /* @__PURE__ */ jsx("tbody", { children })
    ] }),
    /* @__PURE__ */ jsx(CardFooter, { className: "py-4", children: /* @__PURE__ */ jsx("nav", { "aria-label": "....", children: /* @__PURE__ */ jsx(
      Pagination,
      {
        currentPage,
        rowPerPage: data.per_page,
        totalPosts: data.total,
        onPageChange: pageChange,
        previousPage,
        nextPage,
        lastPage: data.last_page
      }
    ) }) })
  ] }) });
};
CustomTable.propTypes = {
  tableHead: PropTypes.string.isRequired,
  data: PropTypes.array,
  headData: PropTypes.array.isRequired,
  toggleModal: PropTypes.func,
  addData: PropTypes.func
};
({
  tableHead: PropTypes.string.isRequired,
  data: PropTypes.array
});
const headRow = ["No", "Keperluan", "Jumlah Keluar", "Tanggal Keluar", "Keterangan", "Action"];
const DanaKeluar = (props) => {
  const { auth, danaKeluars } = props;
  const [isOpen, setIsOpen] = useState(false);
  const [filtered, setFiltered] = useState(null);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const addCommas = (num) => num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  const removeNonNumeric = (num) => num.toString().replace(/[^0-9]/g, "");
  const addData = () => {
    setIsOpen(true);
    setFiltered(null);
  };
  const toggleModal = () => {
    setIsOpen(isOpen != isOpen);
  };
  const editData = (value) => {
    setFiltered(value);
    setIsOpen(true);
  };
  const deleteData = (value) => {
    setFiltered(value);
    setDeleteOpen(true);
  };
  const deleteToggle = () => {
    setDeleteOpen(deleteOpen != deleteOpen);
  };
  return /* @__PURE__ */ jsx(
    AdminLayout,
    {
      user: auth.user,
      header: "Dana Keluar",
      children: /* @__PURE__ */ jsxs("header", { className: "bg-gradient-info pb-8 pt-5 pt-md-8", children: [
        /* @__PURE__ */ jsx(Container, { fluid: true, children: /* @__PURE__ */ jsx(Row, { children: /* @__PURE__ */ jsx("div", { className: "col", children: /* @__PURE__ */ jsx(
          CustomTable,
          {
            data: danaKeluars,
            tableHead: "Dana Keluar",
            headData: headRow,
            toggleModal,
            addData,
            children: danaKeluars.map((danaKeluar, index) => {
              return /* @__PURE__ */ jsxs("tr", { children: [
                /* @__PURE__ */ jsx("th", { scope: "row", children: index + 1 }),
                /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx("span", { className: "mb-0 text-sm", children: danaKeluar.keperluan }) }),
                /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx("span", { className: "mb-0 text-sm", children: "Rp " + addCommas(removeNonNumeric(danaKeluar.jumlah_keluar)) }) }),
                /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx("span", { className: "mb-0 text-sm", children: moment(danaKeluar.tanggal_keluar).format("DD MMMM YYYY") }) }),
                /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx("span", { className: "mb-0 text-sm", children: danaKeluar.keterangan }) }),
                /* @__PURE__ */ jsxs("td", { children: [
                  /* @__PURE__ */ jsxs(
                    Button,
                    {
                      color: "warning",
                      size: "sm",
                      onClick: () => editData(danaKeluar),
                      children: [
                        /* @__PURE__ */ jsx("i", { class: "fa-solid fa-pen-to-square mr-2" }),
                        "Edit"
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxs(
                    Button,
                    {
                      color: "danger",
                      size: "sm",
                      onClick: () => deleteData(danaKeluar),
                      children: [
                        /* @__PURE__ */ jsx("i", { class: "fa-solid fa-trash-can mr-2" }),
                        "Hapus"
                      ]
                    }
                  )
                ] })
              ] });
            })
          }
        ) }) }) }),
        /* @__PURE__ */ jsx(
          Tambah,
          {
            isOpen,
            toggleModal,
            filteredData: filtered
          }
        ),
        /* @__PURE__ */ jsx(
          Delete,
          {
            isOpen: deleteOpen,
            toggleModal: deleteToggle,
            deleteData: filtered
          }
        )
      ] })
    }
  );
};
export {
  DanaKeluar as default
};
