import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { useRef, useState } from "react";
import { useForm } from "@inertiajs/react";
import { Form, Row, Col, FormGroup, Label, Input, FormFeedback, InputGroup, Button } from "reactstrap";
function UpdatePasswordForm({ className = "" }) {
  const passwordInput = useRef();
  const currentPasswordInput = useRef();
  const [passwordShow, setPasswordShow] = useState(false);
  const togglePassword = () => {
    setPasswordShow((data2) => !data2);
  };
  const { data, setData, errors, put, reset, processing, recentlySuccessful } = useForm({
    current_password: "",
    password: "",
    password_confirmation: ""
  });
  const updatePassword = (e) => {
    e.preventDefault();
    put(route("password.update"), {
      preserveScroll: true,
      onSuccess: () => reset(),
      onError: (errors2) => {
        if (errors2.password) {
          reset("password", "password_confirmation");
          passwordInput.current.focus();
        }
        if (errors2.current_password) {
          reset("current_password");
          currentPasswordInput.current.focus();
        }
      }
    });
  };
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs(Form, { role: "form", onSubmit: updatePassword, children: [
    /* @__PURE__ */ jsx(Row, { children: /* @__PURE__ */ jsx(Col, { lg: "6", children: /* @__PURE__ */ jsxs(FormGroup, { children: [
      /* @__PURE__ */ jsx(
        Label,
        {
          className: "form-control-label",
          htmlFor: "current_password",
          children: "Current Password"
        }
      ),
      /* @__PURE__ */ jsx(
        Input,
        {
          id: "current_password",
          ref: currentPasswordInput,
          value: data.current_password,
          onChange: (e) => setData("current_password", e.target.value),
          type: "password",
          autoComplete: "current-password",
          className: "form-control-alternative",
          invalid: errors.current_password && true,
          placeholder: "Your current password"
        }
      ),
      /* @__PURE__ */ jsx(FormFeedback, { children: errors.current_password })
    ] }) }) }),
    /* @__PURE__ */ jsxs(Row, { children: [
      /* @__PURE__ */ jsx(Col, { lg: "6", children: /* @__PURE__ */ jsxs(FormGroup, { children: [
        /* @__PURE__ */ jsx(
          Label,
          {
            className: "form-control-label",
            htmlFor: "password",
            children: "New Password"
          }
        ),
        /* @__PURE__ */ jsxs(InputGroup, { className: "input-group-alternative", children: [
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "password",
              ref: passwordInput,
              value: data.password,
              onChange: (e) => setData("password", e.target.value),
              type: passwordShow ? "text" : "password",
              autoComplete: "new-password",
              name: "password",
              invalid: errors.password && true,
              placeholder: "Your New Password"
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              className: "bg-transparent shadow",
              onMouseOver: className = "text-primary",
              onClick: togglePassword,
              children: /* @__PURE__ */ jsx("i", { className: "fa-regular fa-eye" })
            }
          )
        ] }),
        errors.password && /* @__PURE__ */ jsx("small", { className: "d-flex justify-content-start text-danger form-text", children: errors.password })
      ] }) }),
      /* @__PURE__ */ jsx(Col, { lg: "6", children: /* @__PURE__ */ jsxs(FormGroup, { children: [
        /* @__PURE__ */ jsx(
          Label,
          {
            className: "form-control-label",
            htmlFor: "password-confirmation",
            children: "Password Confirmation"
          }
        ),
        /* @__PURE__ */ jsxs(InputGroup, { className: "input-group-alternative", children: [
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "password-confirmation",
              ref: passwordInput,
              value: data.password_confirmation,
              onChange: (e) => setData("password_confirmation", e.target.value),
              type: passwordShow ? "text" : "password",
              autoComplete: "new-password",
              className: "form-control-alternative",
              invalid: errors.password_confirmation && true,
              placeholder: "Your Password Confirmation",
              name: "password_confirmation"
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              className: "bg-transparent shadow",
              onMouseOver: className = "text-primary",
              onClick: togglePassword,
              children: /* @__PURE__ */ jsx("i", { className: "fa-regular fa-eye" })
            }
          )
        ] }),
        errors.password_confirmation && /* @__PURE__ */ jsx("small", { className: "d-flex justify-content-start text-danger form-text", children: errors.password_confirmation })
      ] }) })
    ] }),
    /* @__PURE__ */ jsx(Row, { children: /* @__PURE__ */ jsx(Col, { lg: "6", children: /* @__PURE__ */ jsx(
      Button,
      {
        color: "primary",
        size: "sm",
        type: "submit",
        disabled: processing,
        children: "Save"
      }
    ) }) })
  ] }) });
}
export {
  UpdatePasswordForm as default
};
