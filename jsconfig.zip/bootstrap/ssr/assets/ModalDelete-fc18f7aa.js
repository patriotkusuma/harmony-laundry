import { jsxs, jsx } from "react/jsx-runtime";
import { useEffect } from "react";
import PropTypes from "prop-types";
import { Modal, Form, FormGroup, Label, Input, FormFeedback, Row, Col, InputGroup, InputGroupText, Button, Pagination as Pagination$1, PaginationItem, PaginationLink } from "reactstrap";
import { useForm } from "@inertiajs/react";
const ModalJenis = (props) => {
  const { isOpen, filteredData, toggleModal } = props;
  const { data, setData, errors, reset, patch, post, get, processing, recentySuccessfull } = useForm({
    id: "",
    nama: "",
    harga: "",
    tipe: "",
    keterangan: ""
  });
  useEffect(() => {
    if (filteredData != null) {
      setData(filteredData);
    } else {
      setData({
        id: "",
        nama: "",
        harga: "",
        tipe: "",
        keterangan: ""
      });
    }
  }, [filteredData]);
  const submit = (e) => {
    if (filteredData == null) {
      post(route(route().current()), {
        onSuccess: () => toggleModal()
      });
    } else {
      patch(route("jenis-cuci.update", filteredData, filteredData.id), {
        preserveState: true,
        replace: true,
        preserveScroll: true,
        onSuccess: () => toggleModal()
      });
    }
  };
  return /* @__PURE__ */ jsxs(
    Modal,
    {
      className: "modal-dialog-centered",
      toggle: toggleModal,
      isOpen,
      children: [
        /* @__PURE__ */ jsxs("div", { className: "modal-header", children: [
          /* @__PURE__ */ jsxs("h2", { className: "modal-title", id: "modal-title-default", children: [
            filteredData == null ? "Tambah" : "Edit",
            " Data Paket Laundry"
          ] }),
          /* @__PURE__ */ jsx(
            "button",
            {
              "aria-label": "close",
              className: "close",
              "data-dismiss": "modal",
              type: "button",
              onClick: toggleModal,
              children: /* @__PURE__ */ jsx("span", { "aria-hidden": true, children: /* @__PURE__ */ jsx("i", { className: "fa-solid fa-xmark" }) })
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "modal-body", children: /* @__PURE__ */ jsxs(Form, { role: "form", onSubmit: submit, children: [
          /* @__PURE__ */ jsxs(FormGroup, { children: [
            /* @__PURE__ */ jsx(
              Label,
              {
                className: "form-control-label",
                children: "Nama Paket"
              }
            ),
            /* @__PURE__ */ jsx(
              Input,
              {
                className: "form-control-alternative",
                id: "nama",
                name: "nama",
                placeholder: "Nama Paket",
                type: "text",
                autoFocus: true,
                required: true,
                defaultValue: filteredData != null ? filteredData.nama : "",
                onChange: (e) => setData("nama", e.target.value),
                invalid: errors.nama && true
              }
            ),
            /* @__PURE__ */ jsx(FormFeedback, { children: errors.nama && errors.nama })
          ] }),
          /* @__PURE__ */ jsxs(Row, { children: [
            /* @__PURE__ */ jsx(Col, { children: /* @__PURE__ */ jsxs(FormGroup, { children: [
              /* @__PURE__ */ jsx(
                Label,
                {
                  className: "form-control-label",
                  children: "Harga"
                }
              ),
              /* @__PURE__ */ jsxs(InputGroup, { className: "input-group-alternative", children: [
                /* @__PURE__ */ jsx(InputGroupText, { children: "Rp" }),
                /* @__PURE__ */ jsx(
                  Input,
                  {
                    className: "form-control-alternative",
                    id: "harga",
                    name: "harga",
                    placeholder: "Harga",
                    type: "number",
                    min: "0",
                    autoFocus: true,
                    required: true,
                    defaultValue: filteredData != null ? filteredData.harga : "",
                    onChange: (e) => setData("harga", e.target.value),
                    invalid: errors.harga && true
                  }
                )
              ] }),
              errors.harga && /* @__PURE__ */ jsx("small", { style: { color: "#fb6340" }, className: "text-sm justify-content-start", children: errors.harga })
            ] }) }),
            /* @__PURE__ */ jsx(Col, { children: /* @__PURE__ */ jsxs(FormGroup, { children: [
              /* @__PURE__ */ jsx(
                "label",
                {
                  className: "form-control-label",
                  htmlFor: "exampleFormControlSelect1",
                  children: "Tipe"
                }
              ),
              /* @__PURE__ */ jsx("br", {}),
              /* @__PURE__ */ jsxs(
                Input,
                {
                  bsSize: "lg",
                  className: "form-control form-control-alternative form-select",
                  type: "select",
                  id: "tipe",
                  name: "tipe",
                  defaultValue: filteredData != null ? filteredData.tipe : "",
                  onChange: (e) => setData("tipe", e.target.value),
                  invalid: errors.tipe && true,
                  required: true,
                  children: [
                    /* @__PURE__ */ jsx("option", { value: "", children: "Pilih Tipe" }),
                    /* @__PURE__ */ jsx("option", { value: "per_kilo", children: "Per Kilo" }),
                    /* @__PURE__ */ jsx("option", { value: "satuan", children: "Satuan" })
                  ]
                }
              ),
              /* @__PURE__ */ jsx(FormFeedback, { children: errors.tipe && errors.tipe })
            ] }) })
          ] }),
          /* @__PURE__ */ jsxs(FormGroup, { children: [
            /* @__PURE__ */ jsx(
              Label,
              {
                className: "form-control-label",
                children: "Keterangan"
              }
            ),
            /* @__PURE__ */ jsx(
              Input,
              {
                className: "form-control-alternative",
                id: "keterangan",
                name: "keterangan",
                placeholder: "Keterangan",
                type: "textarea",
                rows: "4",
                autoFocus: true,
                defaultValue: filteredData != null ? filteredData.keterangan : "",
                onChange: (e) => setData("keterangan", e.target.value),
                invalid: errors.keterangan && true
              }
            ),
            /* @__PURE__ */ jsx(FormFeedback, { children: errors.keterangan && errors.keterangan })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "modal-footer", children: [
          /* @__PURE__ */ jsxs(Button, { color: "primary", type: "submit", disabled: processing, onClick: submit, children: [
            /* @__PURE__ */ jsx("i", { className: "fa-regular fa-floppy-disk" }),
            /* @__PURE__ */ jsx("span", { children: "Save changes" })
          ] }),
          /* @__PURE__ */ jsx(
            Button,
            {
              className: "ml-auto",
              color: "link",
              "data-dismiss": "modal",
              type: "button",
              onClick: toggleModal,
              children: "Close"
            }
          )
        ] })
      ]
    }
  );
};
ModalJenis.propTypes = {
  isOpen: PropTypes.bool,
  toggleModal: PropTypes.func,
  filteredData: PropTypes.any
};
const Pagination = ({ currentPage, rowPerPage, totalPosts, onPageChange, previousPage, nextPage, lastPage }) => {
  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(totalPosts / rowPerPage); i++) {
    pageNumbers.push(i);
  }
  return /* @__PURE__ */ jsxs(
    Pagination$1,
    {
      className: "pagination justify-content-end mb-0",
      listClassName: "justify-content-end mb-0",
      children: [
        /* @__PURE__ */ jsx(PaginationItem, { children: /* @__PURE__ */ jsxs(
          PaginationLink,
          {
            onClick: previousPage,
            children: [
              /* @__PURE__ */ jsx("i", { className: "fa fa-angle-left" }),
              /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Previous" })
            ]
          }
        ) }),
        pageNumbers.map((number, index) => /* @__PURE__ */ jsx(
          PaginationItem,
          {
            className: currentPage == number ? "active" : "",
            children: /* @__PURE__ */ jsx(
              PaginationLink,
              {
                onClick: () => onPageChange(number),
                children: number
              },
              number
            )
          },
          index
        )),
        /* @__PURE__ */ jsx(
          PaginationItem,
          {
            className: lastPage == currentPage ? "disabled" : "",
            children: /* @__PURE__ */ jsxs(
              PaginationLink,
              {
                onClick: nextPage,
                children: [
                  /* @__PURE__ */ jsx("i", { className: "fa fa-angle-right" }),
                  /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Previous" })
                ]
              }
            )
          }
        )
      ]
    }
  );
};
const ModalDelete = (props) => {
  const { isOpen, toggleModal, deleteData } = props;
  const { delete: destroy } = useForm();
  const submit = (e) => {
    e.preventDefault();
    destroy(
      route("jenis-cuci.destroy", deleteData.id),
      {
        preserveScroll: true,
        preserveState: true,
        replace: true,
        onSuccess: () => toggleModal()
      }
    );
  };
  return /* @__PURE__ */ jsxs(
    Modal,
    {
      className: "modal-dialog-centered",
      toggle: toggleModal,
      isOpen,
      children: [
        /* @__PURE__ */ jsxs("div", { className: "modal-header", children: [
          /* @__PURE__ */ jsx("h2", { className: "modal-title", id: "modal-title-default", children: "Hapus Data" }),
          /* @__PURE__ */ jsx(
            "button",
            {
              "aria-label": "close",
              className: "close",
              "data-dismiss": "modal",
              type: "button",
              onClick: toggleModal,
              children: /* @__PURE__ */ jsx("span", { "aria-hidden": true, children: /* @__PURE__ */ jsx("i", { className: "fa-solid fa-xmark" }) })
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "modal-body", children: /* @__PURE__ */ jsxs(Row, { className: "align-items-center", children: [
          /* @__PURE__ */ jsx(Col, { md: "2", children: /* @__PURE__ */ jsx("h1", { className: "text-danger", children: /* @__PURE__ */ jsx("i", { class: "fa-solid fa-triangle-exclamation fa-2xl" }) }) }),
          /* @__PURE__ */ jsx(Col, { md: "10 justify-content-start", children: /* @__PURE__ */ jsxs("h3", { className: "", children: [
            "Apakah anda yakin menghapus data",
            /* @__PURE__ */ jsx(
              Button,
              {
                color: "danger",
                size: "sm",
                children: deleteData != null ? deleteData.nama : ""
              }
            ),
            /* @__PURE__ */ jsx("span", { className: "", children: "?" })
          ] }) })
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "modal-footer", children: [
          /* @__PURE__ */ jsxs(
            Button,
            {
              color: "danger",
              type: "submit",
              size: "md",
              onClick: submit,
              children: [
                /* @__PURE__ */ jsx("i", { className: "fa-regular fa-trash-can" }),
                /* @__PURE__ */ jsx("span", { children: "Ya, Hapus Data" })
              ]
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              className: "ml-auto",
              color: "link",
              "data-dismiss": "modal",
              type: "button",
              onClick: toggleModal,
              children: "Close"
            }
          )
        ] })
      ]
    }
  );
};
ModalDelete.propTypes = {
  isOpen: PropTypes.bool,
  toggleModal: PropTypes.func,
  deleteData: PropTypes.any
};
export {
  ModalJenis as M,
  Pagination as P,
  ModalDelete as a
};
