import { jsx, jsxs } from "react/jsx-runtime";
import { G as GuestLayout } from "./GuestLayout-c9593457.js";
import "./TextInput-1224a4d9.js";
import { useForm, Link } from "@inertiajs/react";
import { Col, Card, CardBody, Alert, Form, FormGroup, InputGroup, InputGroupText, Input, Button, Row } from "reactstrap";
import "./AuthNavbar-1bda6225.js";
import "react";
function ForgotPassword({ status }) {
  const { data, setData, post, processing, errors } = useForm({
    email: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("password.email"));
  };
  return /* @__PURE__ */ jsx(GuestLayout, { children: /* @__PURE__ */ jsxs(Col, { lg: "5", md: "7", children: [
    /* @__PURE__ */ jsx(Card, { className: "bg-secondary shadow border-0", children: /* @__PURE__ */ jsxs(CardBody, { children: [
      /* @__PURE__ */ jsx("div", { className: "text-muted text-center mt-2 mb-3", children: /* @__PURE__ */ jsx("strong", { children: "Forgot Password" }) }),
      /* @__PURE__ */ jsx("div", { className: "mb-4 text-sm text-muted", children: "Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one." }),
      status && /* @__PURE__ */ jsxs(Alert, { color: "warning", children: [
        /* @__PURE__ */ jsx("span", { className: "alert-inner--icon", children: /* @__PURE__ */ jsx("i", { className: "ni ni-like-2" }) }),
        " ",
        /* @__PURE__ */ jsxs("span", { className: "alert-inner--text", children: [
          /* @__PURE__ */ jsx("strong", { children: "Warning!" }),
          status
        ] })
      ] }),
      /* @__PURE__ */ jsx(Form, { role: "form", onSubmit: submit, children: /* @__PURE__ */ jsxs(FormGroup, { className: "mb-3", children: [
        /* @__PURE__ */ jsxs(InputGroup, { className: "input-group-alternative", children: [
          /* @__PURE__ */ jsx(InputGroupText, { children: /* @__PURE__ */ jsx("i", { className: "ni ni-email-83" }) }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "email",
              name: "email",
              value: data.email,
              autoFocus: true,
              placeholder: errors.email ? errors.email : "Email",
              type: "email",
              autoComplete: "username",
              onChange: (e) => setData("email", e.target.value),
              className: errors.email ? "is-invalid" : "",
              valid: errors.email && true
            }
          )
        ] }),
        errors.email && /* @__PURE__ */ jsx("small", { className: "d-flex justify-content-start text-danger form-text ", children: errors.email }),
        /* @__PURE__ */ jsx("div", { className: "text-center", children: /* @__PURE__ */ jsx(Button, { className: "my-4", color: "primary", disabled: processing, type: "submit", children: "Send email reset link" }) })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsxs(Row, { className: "mt-3", children: [
      /* @__PURE__ */ jsx(Col, { xs: "6", children: /* @__PURE__ */ jsx(
        Link,
        {
          className: "text-light",
          href: route("login"),
          children: /* @__PURE__ */ jsx("small", { children: "Already registered?" })
        }
      ) }),
      /* @__PURE__ */ jsx(Col, { className: "text-right", xs: "6", children: /* @__PURE__ */ jsx(
        Link,
        {
          className: "text-light",
          href: route("register"),
          children: /* @__PURE__ */ jsx("small", { children: "Create new account" })
        }
      ) })
    ] })
  ] }) });
}
export {
  ForgotPassword as default
};
