import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { G as GuestLayout } from "./GuestLayout-c9593457.js";
import { Col, Card, CardHeader, Alert, Button, CardBody, Form, FormGroup, InputGroup, InputGroupText, Input, Row } from "reactstrap";
import { useForm, Link } from "@inertiajs/react";
import "./AuthNavbar-1bda6225.js";
function Login({ status, canResetPassword }) {
  const [showPassword, setShowPassword] = useState(false);
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
    remember: false
  });
  const togglePassword = () => {
    setShowPassword((data2) => !data2);
  };
  useEffect(() => {
    return () => {
      reset("password");
    };
  }, []);
  const submit = (e) => {
    e.preventDefault();
    post(route("login"));
  };
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(GuestLayout, { children: /* @__PURE__ */ jsxs(Col, { lg: "5", md: "7", children: [
    /* @__PURE__ */ jsxs(Card, { className: "bg-secondary shadow border-0", children: [
      /* @__PURE__ */ jsxs(CardHeader, { className: "bg-transparent pb-5", children: [
        status && /* @__PURE__ */ jsxs(Alert, { color: "warning", children: [
          /* @__PURE__ */ jsx("span", { className: "alert-inner--icon", children: /* @__PURE__ */ jsx("i", { className: "ni ni-like-2" }) }),
          " ",
          /* @__PURE__ */ jsxs("span", { className: "alert-inner--text", children: [
            /* @__PURE__ */ jsx("strong", { children: "Warning!" }),
            status
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "text-muted text-center mt-2 mb-3", children: /* @__PURE__ */ jsx("small", { children: "Sign in with" }) }),
        /* @__PURE__ */ jsxs("div", { className: "btn-wrapper text-center", children: [
          /* @__PURE__ */ jsxs(
            Button,
            {
              className: "btn-neutral btn-icon",
              color: "default",
              href: "#pablo",
              onClick: (e) => e.preventDefault(),
              children: [
                /* @__PURE__ */ jsx("span", { className: "btn-inner--icon", children: /* @__PURE__ */ jsx(
                  "img",
                  {
                    alt: "...",
                    src: "/assets/img/icons/common/github.svg"
                  }
                ) }),
                /* @__PURE__ */ jsx("span", { className: "btn-inner--text", children: "Github" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            Button,
            {
              className: "btn-neutral btn-icon",
              color: "default",
              href: "#pablo",
              onClick: (e) => e.preventDefault(),
              children: [
                /* @__PURE__ */ jsx("span", { className: "btn-inner--icon", children: /* @__PURE__ */ jsx(
                  "img",
                  {
                    alt: "...",
                    src: "/assets/img/icons/common/google.svg"
                  }
                ) }),
                /* @__PURE__ */ jsx("span", { className: "btn-inner--text", children: "Google" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs(CardBody, { className: "text-center text-muted mb-4", children: [
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("small", { children: "Or sign in with credentials" }) }),
        /* @__PURE__ */ jsxs(Form, { role: "form", onSubmit: submit, children: [
          /* @__PURE__ */ jsxs(FormGroup, { className: "mb-3", children: [
            /* @__PURE__ */ jsxs(InputGroup, { className: "input-group-alternative", children: [
              /* @__PURE__ */ jsx(InputGroupText, { children: /* @__PURE__ */ jsx("i", { className: "ni ni-email-83" }) }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "email",
                  name: "email",
                  value: data.email,
                  autoFocus: true,
                  placeholder: errors.email ? errors.email : "Email",
                  type: "email",
                  autoComplete: "username",
                  onChange: (e) => setData("email", e.target.value),
                  className: errors.email ? "is-invalid" : "",
                  valid: errors.email && true
                }
              )
            ] }),
            errors.email && /* @__PURE__ */ jsx("small", { className: "d-flex justify-content-start text-danger form-text ", children: errors.email })
          ] }),
          /* @__PURE__ */ jsxs(FormGroup, { children: [
            /* @__PURE__ */ jsxs(InputGroup, { className: "input-group-alternative", children: [
              /* @__PURE__ */ jsx(InputGroupText, { children: /* @__PURE__ */ jsx("i", { className: "ni ni-lock-circle-open" }) }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "password",
                  name: "password",
                  value: data.password,
                  placeholder: "Password",
                  type: showPassword ? "text" : "password",
                  autoComplete: "new-password",
                  onChange: (e) => setData("password", e.target.value),
                  invalid: errors.password && true
                }
              ),
              /* @__PURE__ */ jsx(
                Button,
                {
                  className: "bg-transparent shadow text-muted",
                  onClick: togglePassword,
                  children: /* @__PURE__ */ jsx("i", { className: "fa-regular fa-eye" })
                }
              )
            ] }),
            errors.password && /* @__PURE__ */ jsx("small", { className: "d-flex justify-content-start text-danger form-text text-danger", children: errors.password })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "custom-control custom-control-alternative custom-checkbox", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                className: "custom-control-input",
                id: "customCheckLogin",
                type: "checkbox",
                name: "remember",
                checked: data.remember,
                onChange: (e) => setData("remember", e.target.checked)
              }
            ),
            /* @__PURE__ */ jsx(
              "label",
              {
                className: "custom-control-label",
                htmlFor: "customCheckLogin",
                children: /* @__PURE__ */ jsx("span", { className: "text-muted", children: "Remember me" })
              }
            )
          ] }),
          /* @__PURE__ */ jsx("div", { className: "text-center", children: /* @__PURE__ */ jsx(Button, { className: "my-4", color: "primary", disabled: processing, type: "submit", children: "Sign in" }) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Row, { className: "mt-3", children: [
      /* @__PURE__ */ jsx(Col, { xs: "6", children: canResetPassword && /* @__PURE__ */ jsx(
        Link,
        {
          className: "text-light",
          href: route("password.request"),
          children: /* @__PURE__ */ jsx("small", { children: "Forgot Password?" })
        }
      ) }),
      /* @__PURE__ */ jsx(Col, { className: "text-right", xs: "6", children: /* @__PURE__ */ jsx(
        Link,
        {
          className: "text-light",
          href: route("register"),
          children: /* @__PURE__ */ jsx("small", { children: "Create new account" })
        }
      ) })
    ] })
  ] }) }) });
}
export {
  Login as default
};
