import { jsx } from "react/jsx-runtime";
import { A as AdminLayout } from "./AdminLayout-9fb4ec8e.js";
import "react";
import { Container, Row } from "reactstrap";
import "@inertiajs/react";
import "prop-types";
const Customer = (props) => {
  const { auth, customers, flash } = props;
  return /* @__PURE__ */ jsx(
    AdminLayout,
    {
      header: "Customer",
      user: auth.user,
      children: /* @__PURE__ */ jsx("header", { className: "bg-gradient-info pb-8 pt-5 pt-md-8", children: /* @__PURE__ */ jsx(Container, { fluid: true, children: /* @__PURE__ */ jsx(Row, { children: /* @__PURE__ */ jsx("div", { className: "col" }) }) }) })
    }
  );
};
export {
  Customer as default
};
