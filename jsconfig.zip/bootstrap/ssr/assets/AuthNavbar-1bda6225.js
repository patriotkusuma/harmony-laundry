import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import "react";
import { Container, Row, Col, Nav, NavItem, NavLink, Navbar, NavbarBrand, UncontrolledCollapse } from "reactstrap";
import { usePage, Link } from "@inertiajs/react";
function AuthFooter() {
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("footer", { className: "py-5", children: /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsxs(Row, { className: "align-items-center justify-content-xl-between", children: [
    /* @__PURE__ */ jsx(Col, { xl: "6", children: /* @__PURE__ */ jsxs("div", { className: "copyright text-center text-xl-left text-muted", children: [
      "© ",
      (/* @__PURE__ */ new Date()).getFullYear(),
      " ",
      /* @__PURE__ */ jsx(
        "a",
        {
          className: "fontweight-bold ml-1",
          href: "https://www.creative-tim.com?ref=adr-auth-footer",
          target: "_blank",
          children: "Creative Tim"
        }
      )
    ] }) }),
    /* @__PURE__ */ jsx(Col, { xl: "6", children: /* @__PURE__ */ jsxs(Nav, { className: "nav-footer justify-content-center justif-content-xl-end", children: [
      /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsx(
        NavLink,
        {
          href: "https://www.creative-tim.com?ref=adr-auth-footer",
          target: "_blank",
          children: "Creative Tim"
        }
      ) }),
      /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsx(
        NavLink,
        {
          href: "https://www.creative-tim.com/presentation?ref=adr-auth-footer",
          target: "_blank",
          children: "About Us"
        }
      ) }),
      /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsx(
        NavLink,
        {
          href: "http://blog.creative-tim.com?ref=adr-auth-footer",
          target: "_blank",
          children: "Blog"
        }
      ) }),
      /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsx(
        NavLink,
        {
          href: "https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md?ref=adr-auth-footer",
          target: "_blank",
          children: "MIT License"
        }
      ) })
    ] }) })
  ] }) }) }) });
}
function AuthNavbar() {
  const user = usePage().props.auth.user;
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(Navbar, { className: "navbar-top navbar-horizontal navbar-dark", expand: "md", children: /* @__PURE__ */ jsxs(Container, { className: "px-4", children: [
    /* @__PURE__ */ jsx(NavbarBrand, { tag: Link, children: /* @__PURE__ */ jsx(
      "img",
      {
        alt: "...",
        src: "/assets/img/brand/argon-react-white.png"
      }
    ) }),
    /* @__PURE__ */ jsx("button", { className: "navbar-toggler", id: "navbar-collapse-main", children: /* @__PURE__ */ jsx("span", { className: "navbar-toggler-icon" }) }),
    /* @__PURE__ */ jsxs(UncontrolledCollapse, { navbar: true, toggler: "#navbar-collapse-main", children: [
      /* @__PURE__ */ jsx("div", { className: "navbar-collapse-header d-md-none", children: /* @__PURE__ */ jsxs(Row, { children: [
        /* @__PURE__ */ jsx(Col, { className: "collapse-brand", xs: "6", children: /* @__PURE__ */ jsx(Link, { href: "/", children: /* @__PURE__ */ jsx(
          "img",
          {
            alt: "...",
            src: "/assets/img/brand/argon-react.png"
          }
        ) }) }),
        /* @__PURE__ */ jsx(Col, { className: "collapse-close", xs: "6", children: /* @__PURE__ */ jsxs("button", { className: "navbar-toggler", id: "navbar-collapse-main", children: [
          /* @__PURE__ */ jsx("span", {}),
          /* @__PURE__ */ jsx("span", {})
        ] }) })
      ] }) }),
      /* @__PURE__ */ jsx(Nav, { className: "ml-auto", navbar: true, children: user ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsxs(NavLink, { className: "nav-link-icon", href: route("dashboard"), tag: Link, children: [
          /* @__PURE__ */ jsx("i", { className: "ni ni-planet" }),
          /* @__PURE__ */ jsx("span", { className: "nav-link-inner--text", children: "Dashboard" })
        ] }) }),
        /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsxs(
          NavLink,
          {
            href: "/admin/user-profile",
            tag: Link,
            className: "nav-link-icon",
            children: [
              /* @__PURE__ */ jsx("i", { className: "ni ni-single-02" }),
              /* @__PURE__ */ jsx("span", { className: "nav-link-inner--text", children: "Profile" })
            ]
          }
        ) })
      ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsxs(NavLink, { className: "nav-link-icon", href: route("register"), tag: Link, children: [
          /* @__PURE__ */ jsx("i", { className: "ni ni-circle-08" }),
          /* @__PURE__ */ jsx("span", { className: "nav-link-inner--text", children: "Register" })
        ] }) }),
        /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsxs(
          NavLink,
          {
            href: route("login"),
            tag: Link,
            className: "nav-link-icon",
            children: [
              /* @__PURE__ */ jsx("i", { className: "ni ni-key-25" }),
              /* @__PURE__ */ jsx("span", { className: "nav-link-inner--text", children: "Login" })
            ]
          }
        ) })
      ] }) })
    ] })
  ] }) }) });
}
export {
  AuthNavbar as A,
  AuthFooter as a
};
