import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import "react";
import { Container, Row, Col, Button, Card, CardHeader, CardBody } from "reactstrap";
import { Head } from "@inertiajs/react";
import "./TextInput-1224a4d9.js";
import UpdatePasswordForm from "./UpdatePasswordForm-00ab926c.js";
import UpdateProfileInformation from "./UpdateProfileInformationForm-b2084213.js";
import { A as AdminLayout } from "./AdminLayout-9fb4ec8e.js";
import "prop-types";
const UserHeader = ({ user }) => {
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs(
    "div",
    {
      className: "header pb-8 pt-5 pt-lg-8 d-flex align-items-center",
      style: {
        minHeight: "600px",
        backgroundImage: "/assets/img/theme/profile-cover.jpg",
        backgroundSize: "cover",
        backgroundPosition: "center top"
      },
      children: [
        /* @__PURE__ */ jsx("span", { className: "mask bg-gradient-default opacity-8" }),
        /* @__PURE__ */ jsx(Container, { className: "d-flex align-items-center", fluid: true, children: /* @__PURE__ */ jsx(Row, { children: /* @__PURE__ */ jsxs(Col, { lg: "7", md: "10", children: [
          /* @__PURE__ */ jsxs("h1", { className: "display-2 text-white", children: [
            "Hello ",
            user.name
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-white mt-0 mb-5", children: "This is your profile page. You can see the progress you've made with your work and manage your projects or assigned tasks" }),
          /* @__PURE__ */ jsx(
            Button,
            {
              color: "info",
              href: "#pablo",
              onClick: (e) => e.preventDefault(),
              children: "Edit Profile"
            }
          )
        ] }) }) })
      ]
    }
  ) });
};
const UserHeader$1 = UserHeader;
function Edit({ auth, mustVerifyEmail, status }) {
  return /* @__PURE__ */ jsxs(
    AdminLayout,
    {
      user: auth.user,
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Profile" }),
        /* @__PURE__ */ jsx(UserHeader$1, { user: auth.user }),
        /* @__PURE__ */ jsx(Container, { className: "mt-7", fluid: true, children: /* @__PURE__ */ jsxs(Row, { children: [
          /* @__PURE__ */ jsx(Col, { className: "order-xl-2 mb-5 mb-xl-0", xl: "4", children: /* @__PURE__ */ jsxs(Card, { className: "card-profile shadow", children: [
            /* @__PURE__ */ jsx(Row, { className: "justify-content-center", children: /* @__PURE__ */ jsx(Col, { className: "order-lg-2", lg: "3", children: /* @__PURE__ */ jsx("div", { className: "card-profile-image", children: /* @__PURE__ */ jsx("a", { href: "#pablo", onClick: (e) => e.preventDefault(), children: /* @__PURE__ */ jsx(
              "img",
              {
                alt: "...",
                className: "rounded-circle",
                src: "/assets/img/theme/team-4-800x800.jpg"
              }
            ) }) }) }) }),
            /* @__PURE__ */ jsx(CardHeader, { className: "text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4", children: /* @__PURE__ */ jsxs("div", { className: "d-flex justify-content-between", children: [
              /* @__PURE__ */ jsx(
                Button,
                {
                  className: "mr-4",
                  color: "info",
                  href: "#palo",
                  onClick: (e) => preventDefault(),
                  size: "sm",
                  children: "Connect"
                }
              ),
              /* @__PURE__ */ jsx(
                Button,
                {
                  className: "mr-4",
                  color: "default",
                  href: "#palo",
                  onClick: (e) => preventDefault(),
                  size: "sm",
                  children: "Message"
                }
              )
            ] }) }),
            /* @__PURE__ */ jsxs(CardBody, { className: "pt-0 pt-md-4", children: [
              /* @__PURE__ */ jsx(Row, { children: /* @__PURE__ */ jsx("div", { className: "col", children: /* @__PURE__ */ jsxs("div", { className: "card-profile-stats d-flex justify-content-center mt-md-5", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("div", { className: "heading", children: "22" }),
                  /* @__PURE__ */ jsx("div", { className: "description", children: "Friends" })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("span", { className: "heading", children: "10" }),
                  /* @__PURE__ */ jsx("span", { className: "description", children: "Photos" })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("span", { className: "heading", children: "89" }),
                  /* @__PURE__ */ jsx("span", { className: "description", children: "Comments" })
                ] })
              ] }) }) }),
              /* @__PURE__ */ jsxs("div", { className: "text-center", children: [
                /* @__PURE__ */ jsxs("h3", { children: [
                  auth.user.name,
                  /* @__PURE__ */ jsx("span", { className: "font-weight-light" })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "h5 font-weight-300", children: [
                  /* @__PURE__ */ jsx("i", { className: "ni location_pin mr-2" }),
                  auth.user.email
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "h5 mt-4", children: [
                  /* @__PURE__ */ jsx("i", { className: "ni business_briefcase-24 mr-2" }),
                  "Solution Manager - Creative Tim Officer"
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("i", { className: "ni education_hat mr-2" }),
                  "University of Computer Science"
                ] }),
                /* @__PURE__ */ jsx("hr", { className: "my-4" }),
                /* @__PURE__ */ jsx("p", { children: "Ryan — the name taken by Melbourne-raised, Brooklyn-based Nick Murphy — writes, performs and records all of his own music." }),
                /* @__PURE__ */ jsx("a", { href: "#pablo", onClick: (e) => e.preventDefault(), children: "Show more" })
              ] })
            ] })
          ] }) }),
          /* @__PURE__ */ jsx(Col, { className: "order-xl-1", xl: "8", children: /* @__PURE__ */ jsxs(Card, { className: "bg-secondary shadow", children: [
            /* @__PURE__ */ jsx(CardHeader, { className: "bg-white border-0", children: /* @__PURE__ */ jsxs(Row, { className: "align-items-center", children: [
              /* @__PURE__ */ jsx(Col, { xs: "8", children: /* @__PURE__ */ jsx("h3", { className: "mb-0", children: "My Account" }) }),
              /* @__PURE__ */ jsx(Col, { className: "text-right", xs: "4", children: /* @__PURE__ */ jsx(
                Button,
                {
                  color: "primary",
                  href: "#pablo",
                  onClick: (e) => preventDefault(),
                  size: "sm",
                  children: "Settings"
                }
              ) })
            ] }) }),
            /* @__PURE__ */ jsxs(CardBody, { children: [
              /* @__PURE__ */ jsx("h6", { className: "heading-small text-muted mb-4", children: "User Information" }),
              /* @__PURE__ */ jsx("div", { className: "pl-lg-4", children: /* @__PURE__ */ jsx(
                UpdateProfileInformation,
                {
                  mustVerifyEmail,
                  status
                }
              ) }),
              /* @__PURE__ */ jsx("hr", { className: "my-4" }),
              /* @__PURE__ */ jsx("h6", { className: "heading-small text-muted mb-4", children: "Update Password" }),
              /* @__PURE__ */ jsx("div", { className: "pl-lg-4", children: /* @__PURE__ */ jsx(UpdatePasswordForm, {}) })
            ] })
          ] }) })
        ] }) })
      ]
    }
  );
}
export {
  Edit as default
};
