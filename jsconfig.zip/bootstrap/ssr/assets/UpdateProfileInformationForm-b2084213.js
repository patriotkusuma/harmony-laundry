import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import "./TextInput-1224a4d9.js";
import { usePage, useForm } from "@inertiajs/react";
import { Form, Row, Col, Alert, FormGroup, Label, Input, FormFeedback, Button } from "reactstrap";
import "react";
function UpdateProfileInformation({ mustVerifyEmail, status, className = "" }) {
  const user = usePage().props.auth.user;
  const { data, setData, patch, errors, processing, recentlySuccessful } = useForm({
    name: user.name,
    email: user.email
  });
  const submit = (e) => {
    e.preventDefault();
    patch(route("profile.update"));
  };
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs(Form, { onSubmit: submit, children: [
    /* @__PURE__ */ jsxs(Row, { children: [
      recentlySuccessful && /* @__PURE__ */ jsx(Col, { sm: "12", children: /* @__PURE__ */ jsxs(Alert, { color: "success", children: [
        /* @__PURE__ */ jsx("strong", { children: "Success!" }),
        " Data tersimpan!"
      ] }) }),
      /* @__PURE__ */ jsx(Col, { lg: "6", children: /* @__PURE__ */ jsxs(FormGroup, { children: [
        /* @__PURE__ */ jsx(
          Label,
          {
            className: "form-control-label",
            htmlFor: "input-fullname",
            children: "Fullname"
          }
        ),
        /* @__PURE__ */ jsx(
          Input,
          {
            className: "form-control-alternative",
            defaultValue: data.name,
            value: data.name,
            onChange: (e) => setData("name", e.target.value),
            id: "input-fullname",
            placeholder: "Full Name",
            type: "text",
            autoFocus: true,
            required: true,
            autoComplete: "name",
            name: "name",
            invalid: errors.name && true
          }
        ),
        /* @__PURE__ */ jsx(FormFeedback, { children: errors.name })
      ] }) }),
      /* @__PURE__ */ jsx(Col, { lg: "6", children: /* @__PURE__ */ jsxs(FormGroup, { children: [
        /* @__PURE__ */ jsx(
          Label,
          {
            className: "form-control-label",
            htmlFor: "input-email",
            children: "Email"
          }
        ),
        /* @__PURE__ */ jsx(
          Input,
          {
            className: "form-control-alternative",
            defaultValue: data.email,
            value: data.email,
            onChange: (e) => setData("email", e.target.value),
            required: true,
            autoComplete: "email",
            id: "input-email",
            name: "email",
            placeholder: "Full Name",
            type: "email",
            invalid: errors.email && true
          }
        ),
        /* @__PURE__ */ jsx(FormFeedback, { children: errors.email })
      ] }) })
    ] }),
    /* @__PURE__ */ jsx(Row, { children: /* @__PURE__ */ jsx(Col, { lg: "6", children: /* @__PURE__ */ jsx(
      Button,
      {
        color: "primary",
        size: "sm",
        type: "submit",
        disabled: processing,
        children: "Save"
      }
    ) }) })
  ] }) });
}
export {
  UpdateProfileInformation as default
};
