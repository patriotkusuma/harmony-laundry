import { jsx } from "react/jsx-runtime";
import { A as AdminLayout } from "./AdminLayout-9fb4ec8e.js";
import "react";
import "@inertiajs/react";
import "reactstrap";
import "prop-types";
function Dashboard({ auth }) {
  return /* @__PURE__ */ jsx(
    AdminLayout,
    {
      user: auth.user,
      children: /* @__PURE__ */ jsx("div", { className: "header bg-gradient-info pb-8 pt-5 pt-md-8" })
    }
  );
}
export {
  Dashboard as default
};
