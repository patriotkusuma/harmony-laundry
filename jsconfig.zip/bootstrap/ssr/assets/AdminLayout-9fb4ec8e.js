import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useState, useRef } from "react";
import { Row, Col, Nav, NavItem, NavLink, Navbar, UncontrolledDropdown, DropdownToggle, Media, DropdownMenu, DropdownItem, Container, NavbarBrand, Collapse, Form, InputGroup, Input, InputGroupText, UncontrolledCollapse } from "reactstrap";
import { useForm, Link } from "@inertiajs/react";
import PropTypes from "prop-types";
const AdminFooter = () => {
  return /* @__PURE__ */ jsx("footer", { className: "footer mx-4", children: /* @__PURE__ */ jsxs(Row, { className: "align-items-center justify-content-xl-between", children: [
    /* @__PURE__ */ jsx(Col, { xl: "6", children: /* @__PURE__ */ jsxs("div", { className: "copyright text-center text-xl-left text-muted", children: [
      "© ",
      (/* @__PURE__ */ new Date()).getFullYear(),
      " ",
      /* @__PURE__ */ jsx(
        "a",
        {
          className: "font-weight-bold ml-1",
          href: "/",
          rel: "noopener noreferrer",
          target: "_blank",
          children: "Harmony Laundry"
        }
      )
    ] }) }),
    /* @__PURE__ */ jsx(Col, { xl: "6", children: /* @__PURE__ */ jsx(Nav, { className: "nav-footer justify-content-center justify-content-xl-end", children: /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsx(
      NavLink,
      {
        href: "/",
        target: "_blank",
        children: "Harmony Laundry"
      }
    ) }) }) })
  ] }) });
};
const AdminNavbar = ({ user, header }) => {
  const { get, post } = useForm();
  const logout = (e) => {
    e.preventDefault();
    route(post("logout"));
  };
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs(Navbar, { className: "navbar-top navbar-dark", expand: "md", id: "navbar-main", children: [
    /* @__PURE__ */ jsx(
      Link,
      {
        className: "h4 mb-0 text-white text-uppercase d-none d-lg-inline-block",
        to: "/",
        children: header
      }
    ),
    /* @__PURE__ */ jsx(Nav, { className: "align-items-center d-none d-md-flex", navbar: true, children: /* @__PURE__ */ jsxs(UncontrolledDropdown, { nav: true, children: [
      /* @__PURE__ */ jsx(DropdownToggle, { className: "pr-0", nav: true, children: /* @__PURE__ */ jsxs(Media, { className: "align-items-center", children: [
        /* @__PURE__ */ jsx("span", { className: "avatar avatar-sm rounded-circle", children: /* @__PURE__ */ jsx(
          "img",
          {
            alt: "...",
            src: "/assets/img/theme/team-4-800x800.jpg"
          }
        ) }),
        /* @__PURE__ */ jsx(Media, { className: "ml-2 d-none d-lg-block", children: /* @__PURE__ */ jsx("span", { className: "mb-0 text-sm font-weight-bold", children: user.name }) })
      ] }) }),
      /* @__PURE__ */ jsxs(DropdownMenu, { className: "dropdown-menu-arrow", right: true, children: [
        /* @__PURE__ */ jsx(DropdownItem, { className: "noti-title", header: true, tag: "div", children: /* @__PURE__ */ jsx("h6", { className: "text-overflow m-0", children: "Welcome!" }) }),
        /* @__PURE__ */ jsxs(DropdownItem, { href: route("profile.edit"), tag: Link, children: [
          /* @__PURE__ */ jsx("i", { className: "ni ni-single-02" }),
          /* @__PURE__ */ jsx("span", { children: "My profile" })
        ] }),
        /* @__PURE__ */ jsxs(DropdownItem, { to: "/admin/user-profile", tag: Link, children: [
          /* @__PURE__ */ jsx("i", { className: "ni ni-settings-gear-65" }),
          /* @__PURE__ */ jsx("span", { children: "Settings" })
        ] }),
        /* @__PURE__ */ jsxs(DropdownItem, { to: "/admin/user-profile", tag: Link, children: [
          /* @__PURE__ */ jsx("i", { className: "ni ni-calendar-grid-58" }),
          /* @__PURE__ */ jsx("span", { children: "Activity" })
        ] }),
        /* @__PURE__ */ jsxs(DropdownItem, { to: "/admin/user-profile", tag: Link, children: [
          /* @__PURE__ */ jsx("i", { className: "ni ni-support-16" }),
          /* @__PURE__ */ jsx("span", { children: "Support" })
        ] }),
        /* @__PURE__ */ jsx(DropdownItem, { divider: true }),
        /* @__PURE__ */ jsxs(DropdownItem, { onClick: logout, children: [
          /* @__PURE__ */ jsx("i", { className: "ni ni-user-run" }),
          /* @__PURE__ */ jsx("span", { children: "Logout" })
        ] })
      ] })
    ] }) })
  ] }) });
};
const AdminNavbar$1 = AdminNavbar;
const Sidebar = (props) => {
  const [collapseOpen, setCollapseOpen] = useState();
  const { bgColor, logo } = props;
  const toggleCollapse = () => {
    setCollapseOpen((data) => !data);
  };
  return /* @__PURE__ */ jsx(
    Navbar,
    {
      className: "navbar-vertical fixed-left navbar-light bg-white",
      expand: "md",
      id: "sidenav-main",
      children: /* @__PURE__ */ jsxs(Container, { fluid: true, children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            className: "navbar-toggler",
            type: "button",
            onClick: toggleCollapse,
            children: /* @__PURE__ */ jsx("span", { className: "navbar-toggler-icon" })
          }
        ),
        logo && /* @__PURE__ */ jsx(NavbarBrand, { className: "pt-0", children: /* @__PURE__ */ jsx(
          "img",
          {
            alt: logo.imgAlt,
            className: "navbar-brand-img",
            src: logo.imgSrc
          }
        ) }),
        /* @__PURE__ */ jsxs(Nav, { className: "align-items-center d-md-none", children: [
          /* @__PURE__ */ jsxs(UncontrolledDropdown, { nav: true, children: [
            /* @__PURE__ */ jsx(DropdownToggle, { nav: true, className: "nav-link-icon", children: /* @__PURE__ */ jsx("i", { className: "ni ni-bell-55" }) }),
            /* @__PURE__ */ jsxs(
              DropdownMenu,
              {
                "aria-labelledby": "navbar-default_dropdown_1",
                className: "dropdown-menu-arrow",
                right: true,
                children: [
                  /* @__PURE__ */ jsx(DropdownItem, { children: "Action" }),
                  /* @__PURE__ */ jsx(DropdownItem, { children: "Another Action" }),
                  /* @__PURE__ */ jsx(DropdownItem, { devider: true }),
                  /* @__PURE__ */ jsx(DropdownItem, { children: "Something else here" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs(UncontrolledDropdown, { nav: true, children: [
            /* @__PURE__ */ jsx(DropdownToggle, { nav: true, children: /* @__PURE__ */ jsx(Media, { className: "align-items-center", children: /* @__PURE__ */ jsx("span", { className: "avatar avatar-sm rounded-circle", children: /* @__PURE__ */ jsx(
              "img",
              {
                alt: "...",
                src: "/assets/img/theme/team-1-800x800.jpg"
              }
            ) }) }) }),
            /* @__PURE__ */ jsxs(DropdownMenu, { className: "dropdown-menu-arrow", right: true, children: [
              /* @__PURE__ */ jsx(DropdownItem, { className: "noti-title", header: true, tag: "div", children: /* @__PURE__ */ jsx("h6", { className: "text-overflow m-0", children: "Welcome !" }) }),
              /* @__PURE__ */ jsxs(DropdownItem, { to: "/admin/user-profile", children: [
                /* @__PURE__ */ jsx("i", { className: "ni ni-single-02" }),
                /* @__PURE__ */ jsx("span", { children: "My profile" })
              ] }),
              /* @__PURE__ */ jsxs(DropdownItem, { to: "/admin/user-profile", children: [
                /* @__PURE__ */ jsx("i", { className: "ni ni-settings-gear-65" }),
                /* @__PURE__ */ jsx("span", { children: "Settings" })
              ] }),
              /* @__PURE__ */ jsxs(DropdownItem, { to: "/admin/user-profile", children: [
                /* @__PURE__ */ jsx("i", { className: "ni ni-calendar-grid-58" }),
                /* @__PURE__ */ jsx("span", { children: "Activity" })
              ] }),
              /* @__PURE__ */ jsxs(DropdownItem, { to: "/admin/user-profile", children: [
                /* @__PURE__ */ jsx("i", { className: "ni ni-support-16" }),
                /* @__PURE__ */ jsx("span", { children: "Support" })
              ] }),
              /* @__PURE__ */ jsx(DropdownItem, { divider: true }),
              /* @__PURE__ */ jsxs(DropdownItem, { href: "#pablo", onClick: (e) => e.preventDefault(), children: [
                /* @__PURE__ */ jsx("i", { className: "ni ni-user-run" }),
                /* @__PURE__ */ jsx("span", { children: "Logout" })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs(Collapse, { navbar: true, isOpen: collapseOpen, children: [
          /* @__PURE__ */ jsx("div", { className: "navbar-collapse-header d-md-none", children: /* @__PURE__ */ jsxs(Row, { children: [
            logo ? /* @__PURE__ */ jsx(Col, { className: "collapse-brand", xs: "6", children: logo.innerLink ? /* @__PURE__ */ jsx(Link, { to: logo.innerLink, children: /* @__PURE__ */ jsx("img", { alt: logo.imgAlt, src: logo.imgSrc }) }) : /* @__PURE__ */ jsx("a", { href: logo.outterLink, children: /* @__PURE__ */ jsx("img", { alt: logo.imgAlt, src: logo.imgSrc }) }) }) : null,
            /* @__PURE__ */ jsx(Col, { className: "collapse-close", xs: "6", children: /* @__PURE__ */ jsxs(
              "button",
              {
                className: "navbar-toggler",
                type: "button",
                onClick: toggleCollapse,
                children: [
                  /* @__PURE__ */ jsx("span", {}),
                  /* @__PURE__ */ jsx("span", {})
                ]
              }
            ) })
          ] }) }),
          /* @__PURE__ */ jsx(Form, { className: "mt-4 mb-3 d-md-none", children: /* @__PURE__ */ jsxs(InputGroup, { className: "input-group-rounded input-group-merge", children: [
            /* @__PURE__ */ jsx(
              Input,
              {
                "aria-label": "Search",
                className: "form-control-rounded form-control-prepended",
                placeholder: "Search",
                type: "search"
              }
            ),
            /* @__PURE__ */ jsx(InputGroupText, { children: /* @__PURE__ */ jsx("span", { className: "fa fa-search" }) })
          ] }) }),
          /* @__PURE__ */ jsxs(Nav, { navbar: true, children: [
            /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsxs(
              NavLink,
              {
                href: route("dashboard"),
                tag: Link,
                active: route().current() === "dashboard",
                className: route().current() === "dashboard" ? "bg-teal text-default" : "",
                children: [
                  /* @__PURE__ */ jsx("i", { className: "ni ni-tv-2 text-primary" }),
                  "Dashboard"
                ]
              }
            ) }),
            /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsxs(
              NavLink,
              {
                href: route("pegawai.index"),
                tag: Link,
                active: route().current() === "pegawai.index",
                className: route().current() === "pegawai.index" ? "bg-teal text-default" : "",
                children: [
                  /* @__PURE__ */ jsx("i", { className: "ni ni-tv-2 text-primary" }),
                  "Pegawai"
                ]
              }
            ) }),
            /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsxs(
              NavLink,
              {
                href: route("dana-keluar.index"),
                tag: Link,
                active: route().current() === "dana-keluar.index",
                className: route().current() === "dana-keluar.index" ? "bg-teal text-default" : "",
                children: [
                  /* @__PURE__ */ jsx("i", { className: "ni ni-tv-2 text-primary" }),
                  "Dana Keluar"
                ]
              }
            ) }),
            /* @__PURE__ */ jsx(NavItem, { children: /* @__PURE__ */ jsxs(
              NavLink,
              {
                href: route("jenis-cuci.index"),
                tag: Link,
                active: route().current() === "jenis-cuci.index" && true,
                className: route().current() === "jenis-cuci.index" ? "bg-teal text-default" : "",
                children: [
                  /* @__PURE__ */ jsx("i", { class: "fa-solid fa-suitcase text-primary " }),
                  "Paket Laundry"
                ]
              }
            ) }),
            /* @__PURE__ */ jsxs(NavItem, { children: [
              /* @__PURE__ */ jsxs(
                NavLink,
                {
                  href: "#",
                  id: "toggler",
                  tag: "a",
                  children: [
                    /* @__PURE__ */ jsx("i", { className: "ni ni-tv-2 text-primary" }),
                    /* @__PURE__ */ jsx("span", { children: "Inventory Management" }),
                    /* @__PURE__ */ jsx("i", { class: "fa-solid fa-angle-down" })
                  ]
                }
              ),
              /* @__PURE__ */ jsx(UncontrolledCollapse, { toggler: "#toggler", defaultOpen: true, children: /* @__PURE__ */ jsxs(
                NavLink,
                {
                  href: route("customers.index"),
                  tag: Link,
                  className: route().current() === "customers.index" ? "bg-teal text-default" : "text-muted",
                  children: [
                    /* @__PURE__ */ jsx("i", { className: "ni ni-tv-2 text-primary" }),
                    "Customer"
                  ]
                }
              ) })
            ] })
          ] }),
          /* @__PURE__ */ jsx("hr", { className: "my-3" }),
          /* @__PURE__ */ jsx("h6", { className: "navbar-heading text-muted", children: "Documentation" }),
          /* @__PURE__ */ jsx(Nav, { className: "mb-md-3", navbar: true }),
          /* @__PURE__ */ jsx(Nav, { className: "mb-md-3", navbar: true, children: /* @__PURE__ */ jsx(NavItem, { className: "active-pro active", children: /* @__PURE__ */ jsxs(NavLink, { href: "https://www.creative-tim.com/product/argon-dashboard-pro-react?ref=adr-admin-sidebar", children: [
            /* @__PURE__ */ jsx("i", { className: "ni ni-spaceship" }),
            "Upgrade to PRO"
          ] }) }) })
        ] })
      ] })
    }
  );
};
Sidebar.propTypes = {
  logo: PropTypes.shape({
    innerLink: PropTypes.string,
    outterLink: PropTypes.string,
    imgSrc: PropTypes.string.isRequired,
    imgAlt: PropTypes.string.isRequired
  })
};
const Sidebar$1 = Sidebar;
function AdminLayout({ user, header, children }) {
  const mainContent = useRef(null);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      Sidebar$1,
      {
        logo: {
          innerLink: route("dashboard"),
          imgSrc: "/assets/img/brand/argon-react.png",
          imgAlt: "..."
        }
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "main-content", ref: mainContent, children: [
      /* @__PURE__ */ jsx(
        AdminNavbar$1,
        {
          header,
          user
        }
      ),
      children,
      /* @__PURE__ */ jsx(AdminFooter, {})
    ] })
  ] });
}
export {
  AdminLayout as A
};
