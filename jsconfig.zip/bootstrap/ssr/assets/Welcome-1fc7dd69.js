import { jsx, Fragment } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { G as GuestLayout } from "./GuestLayout-c9593457.js";
import { Col, Card, CardBody } from "reactstrap";
import { useForm } from "@inertiajs/react";
import "./AuthNavbar-1bda6225.js";
function Welcome({ status, canResetPassword }) {
  useState(false);
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
    remember: false
  });
  useEffect(() => {
    return () => {
      reset("password");
    };
  }, []);
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(GuestLayout, { children: /* @__PURE__ */ jsx(Col, { lg: "5", md: "7", children: /* @__PURE__ */ jsx(Card, { className: "bg-secondary shadow border-0", children: /* @__PURE__ */ jsx(CardBody, { className: "text-center text-muted mb-4", children: /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("small", { children: "Or sign in with credentials" }) }) }) }) }) }) });
}
export {
  Welcome as default
};
