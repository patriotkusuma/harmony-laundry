import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { A as AuthNavbar, a as AuthFooter } from "./AuthNavbar-1bda6225.js";
import React, { useRef } from "react";
import { Container, Row, Col } from "reactstrap";
function AuthenticatedLayout({ children }) {
  const mainContent = useRef(null);
  React.useEffect(() => {
    document.body.classList.add("bg-default");
    return () => {
      document.body.classList.remove("bg-default");
    };
  }, []);
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { className: "main-content", ref: mainContent, children: [
    /* @__PURE__ */ jsx(AuthNavbar, {}),
    /* @__PURE__ */ jsxs("div", { className: "header bg-gradient-info py-7 py-lg", children: [
      /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx("div", { className: "header-body text-center mb-7", children: /* @__PURE__ */ jsx(Row, { className: "justify-content-center", children: /* @__PURE__ */ jsxs(Col, { lg: "5", md: "6", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-white", children: "Welcome !" }),
        /* @__PURE__ */ jsx("p", { className: "text-lead text-light", children: "Use these awesome forms to login or create new account in your project for free." })
      ] }) }) }) }),
      /* @__PURE__ */ jsx("div", { className: "separator separator-bottom separator-skew zindex-100", children: /* @__PURE__ */ jsx(
        "svg",
        {
          xmlns: "http://www.w3.org/2000/svg",
          preserveAspectRatio: "none",
          version: "1.1",
          viewBox: "0 0 2560 100",
          x: "0",
          y: "0",
          children: /* @__PURE__ */ jsx(
            "polygon",
            {
              className: "fill-default",
              points: "2560 0 2560 100 0 100"
            }
          )
        }
      ) })
    ] }),
    /* @__PURE__ */ jsx(Container, { className: "mt--8 pb-5", children: /* @__PURE__ */ jsx(Row, { className: "justify-content-center", children }) }),
    /* @__PURE__ */ jsx(AuthFooter, {})
  ] }) });
}
export {
  AuthenticatedLayout as A
};
